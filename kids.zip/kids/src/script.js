// Function to show selected section and hide others
function showSection(sectionId) {
  const sections = document.querySelectorAll("section");
  sections.forEach((section) => {
    section.style.display = section.id === sectionId ? "block" : "none";
  });
}

// Function to search content
function searchContent() {
  const query = document.getElementById("searchBar").value.toLowerCase();
  // Simulating search logic
}

// Event listeners for navigation links
document.querySelectorAll(".bottom-nav a").forEach((link) => {
  link.addEventListener("click", function (event) {
    event.preventDefault();
    const targetSection = this.getAttribute("href").substring(1);
    showSection(targetSection);
  });
});

// Handle form submission for account
document
  .getElementById("accountForm")
  .addEventListener("submit", function (event) {
    event.preventDefault();
    alert("Logged in successfully!");
  });

// Story generation with Precious
document
  .getElementById("activatePrecious")
  .addEventListener("click", function () {
    document.getElementById("preciousChat").style.display = "block";
    startVoiceRecognition();
  });

// Voice recognition for story type
function startVoiceRecognition() {
  const recognition = new (window.SpeechRecognition ||
    window.webkitSpeechRecognition)();
  recognition.lang = "en-US";

  recognition.onstart = function () {
    console.log("Voice recognition started.");
  };

  recognition.onresult = function (event) {
    const storyType = event.results[0][0].transcript;
    document.getElementById(
      "preciousQuestion"
    ).innerText = `You asked for a story about: ${storyType}`;
    generateStory(storyType);
  };

  recognition.onerror = function (event) {
    console.error("Error occurred in recognition: " + event.error);
  };

  recognition.start();
}

function generateStory(type) {
  const storyTitle = `The Adventure of the ${
    type.charAt(0).toUpperCase() + type.slice(1)
  }`;
  const storyImage = `https://source.unsplash.com/featured/?${type}`; // Automatically fetch a relevant image
  const storyContent = `Once upon a time, there was a brave ${type}. This ${type} had many adventures...`;

  document.getElementById("storyTitle").innerText = storyTitle;
  document.getElementById("storyImage").src = storyImage;
  document.getElementById("storyContent").innerText = storyContent;
  document.getElementById("storyOutput").style.display = "block";

  const utterance = new SpeechSynthesisUtterance(storyContent);
  document.getElementById("speakStory").onclick = function () {
    window.speechSynthesis.speak(utterance);
  };
}

// Initialize the app by showing the home section
showSection("home");
